<?php
require_once "db.php";

$stmt = $pdo->query("
    SELECT b.id, u.username, m.title, m.poster, b.seats, b.created_at
    FROM bookings b
    JOIN users u ON b.user_id = u.id
    JOIN movies m ON b.movie_id = m.id
    ORDER BY b.id DESC
");
$bookings = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Tickets</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container">
    <a class="navbar-brand" href="#">🎟️ Ticket Management</a>
    <a class="nav-link text-light" href="booking.php">Book Tickets</a>
  </div>
</nav>

<div class="container py-5">
  <h3 class="mb-4 text-center">All Bookings</h3>
  <table class="table table-bordered table-striped">
    <thead class="table-dark">
      <tr>
        <th>ID</th>
        <th>User</th>
        <th>Movie</th>
        <th>Poster</th>
        <th>Seats</th>
        <th>Date</th>
        <th>Actions</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ($bookings as $b): ?>
      <tr>
        <td><?= $b['id'] ?></td>
        <td><?= htmlspecialchars($b['username']) ?></td>
        <td><?= htmlspecialchars($b['title']) ?></td>
        <td><img src="assets/<?= htmlspecialchars($b['poster']) ?>" alt="" width="70"></td>
        <td><?= htmlspecialchars($b['seats']) ?></td>
        <td><?= htmlspecialchars($b['created_at']) ?></td>
        <td>
          <button class="btn btn-sm btn-primary" onclick="editBooking(<?= $b['id'] ?>, <?= $b['seats'] ?>)">Edit</button>
          <button class="btn btn-sm btn-danger" onclick="deleteBooking(<?= $b['id'] ?>)">Delete</button>
        </td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>

<script>
async function deleteBooking(id) {
  if (!confirm("Yakin ingin hapus booking ini?")) return;
  const res = await fetch("api.php/" + id, { method: "DELETE" });
  const json = await res.json();
  alert(json.message);
  location.reload();
}

async function editBooking(id, seats) {
  const newSeats = prompt("Masukkan jumlah kursi baru:", seats);
  if (!newSeats) return;
  const res = await fetch("api.php/" + id, {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ seats: newSeats })
  });
  const json = await res.json();
  alert(json.message);
  location.reload();
}
</script>
</body>
</html>
