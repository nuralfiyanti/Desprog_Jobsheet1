<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Book Tickets</title>
    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <header class="bg-dark text-white py-3 mb-4">
        <div class="container d-flex justify-content-between align-items-center">
            <h1 class="h3 mb-0">🎬 Movie Ticketing</h1>
            <nav>
                <ul class="nav">
                    <li class="nav-item"><a href="index.html" class="nav-link text-white">Home</a></li>
                    <li class="nav-item"><a href="booking.php" class="nav-link active text-warning fw-bold">Book Tickets</a></li>
                    <li class="nav-item"><a href="login.html" class="nav-link text-white">Login</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <main class="container">
        <section class="booking my-4">
            <h2 class="mb-3">🎟 Choose a Movie</h2>
            <p class="text-muted">Select a movie to book tickets.</p>
            <div class="row" id="movie-list"></div>

            <form id="booking-form" class="mt-4" hidden>
                <h4 id="selected-movie" class="mb-1"></h4>
                <p id="selected-time" class="text-muted"></p>
                <div class="mb-3">
                    <label for="seats" class="form-label">Number of seats</label>
                    <input type="number" id="seats" name="seats" class="form-control" min="1" max="10" value="1" required>
                </div>
                <button type="submit" class="btn btn-warning fw-bold">Book now</button>
            </form>
        </section>

        <hr>

        <section class="mt-5">
            <h3>📋 Booking List</h3>
            <table class="table table-bordered mt-3">
                <thead class="table-dark">
                    <tr>
                        <th>ID</th>
                        <th>User</th>
                        <th>Movie</th>
                        <th>Seats</th>
                        <th>Booked At</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody id="booking-table"></tbody>
            </table>
        </section>
    </main>

<script>
const movieList = document.getElementById('movie-list');
const bookingForm = document.getElementById('booking-form');
const bookingTable = document.getElementById('booking-table');
const selectedMovie = document.getElementById('selected-movie');
const selectedTime = document.getElementById('selected-time');
let selectedMovieId = null;

// ✅ Fetch daftar film dari API
async function loadMovies() {
    const res = await fetch('api.php?path=movies');
    const movies = await res.json();

    movieList.innerHTML = movies.map(movie => `
        <div class="col-md-4 mb-3">
            <div class="card h-100 shadow-sm movie-option" data-id="${movie.id}" data-title="${movie.title}">
                <img src="${movie.poster_url}" class="card-img-top" alt="${movie.title}">
                <div class="card-body">
                    <h5 class="card-title">${movie.title}</h5>
                    <p class="card-text">Duration: ${movie.duration_minutes} min</p>
                    <button class="btn btn-outline-warning w-100">Select</button>
                </div>
            </div>
        </div>
    `).join('');

    document.querySelectorAll('.movie-option button').forEach(btn => {
        btn.addEventListener('click', e => {
            const card = e.target.closest('.movie-option');
            selectedMovieId = card.dataset.id;
            selectedMovie.textContent = `Booking for: ${card.dataset.title}`;
            selectedTime.textContent = "Today at 7:30 PM";
            bookingForm.hidden = false;
        });
    });
}

// ✅ Fetch daftar booking
async function loadBookings() {
    const res = await fetch('api.php?path=bookings');
    const data = await res.json();

    bookingTable.innerHTML = data.map(b => `
        <tr>
            <td>${b.id}</td>
            <td>${b.fullname}</td>
            <td>${b.title}</td>
            <td>${b.seats}</td>
            <td>${new Date(b.booked_at).toLocaleString()}</td>
            <td>
                <button class="btn btn-sm btn-danger" onclick="deleteBooking(${b.id})">Delete</button>
            </td>
        </tr>
    `).join('');
}

// ✅ Hapus booking
async function deleteBooking(id) {
    if (!confirm("Are you sure?")) return;
    await fetch(`api.php?path=bookings/${id}`, { method: 'DELETE' });
    loadBookings();
}

// ✅ Simpan booking baru
bookingForm.addEventListener('submit', async e => {
    e.preventDefault();
    if (!selectedMovieId) return alert("Select a movie first!");

    const seats = document.getElementById('seats').value;
    const payload = { user_id: 2, movie_id: Number(selectedMovieId), seats: Number(seats) };

    const res = await fetch('api.php?path=bookings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
    });

    const json = await res.json();
    alert(json.message);
    bookingForm.hidden = true;
    loadBookings();
});

loadMovies();
loadBookings();
</script>
</body>
</html>
