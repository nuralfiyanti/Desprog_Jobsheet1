<?php
require_once "db.php";

// Misal user_id=2
$user_id = 2;
$stmt = $pdo->prepare("SELECT b.id, m.title, b.seats, b.booked_at FROM bookings b JOIN movies m ON b.movie_id=m.id WHERE b.user_id=? ORDER BY b.booked_at DESC");
$stmt->execute([$user_id]);
$bookings = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>My Bookings</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<nav class="navbar navbar-dark bg-dark">
<div class="container">
  <a class="navbar-brand" href="index.html">🎬 Movie Ticketing</a>
  <ul class="navbar-nav ms-auto d-flex flex-row">
    <li class="nav-item mx-2"><a class="nav-link" href="booking.php">Book Tickets</a></li>
    <li class="nav-item mx-2"><a class="nav-link active text-warning fw-bold" href="#">My Bookings</a></li>
    <li class="nav-item mx-2"><a class="nav-link" href="tickets.php">View All</a></li>
  </ul>
</div>
</nav>

<div class="container py-5">
<h3>My Bookings</h3>
<table class="table table-bordered table-striped">
<thead class="table-dark">
<tr>
  <th>ID</th>
  <th>Movie</th>
  <th>Seats</th>
  <th>Booked At</th>
  <th>Actions</th>
</tr>
</thead>
<tbody>
<?php if($bookings): ?>
  <?php foreach($bookings as $b): ?>
  <tr>
    <td><?= $b['id'] ?></td>
    <td><?= htmlspecialchars($b['title']) ?></td>
    <td><?= $b['seats'] ?></td>
    <td><?= $b['booked_at'] ?></td>
    <td>
      <button class="btn btn-sm btn-primary" onclick="editBooking(<?= $b['id'] ?>,<?= $b['seats'] ?>)">✏️</button>
      <button class="btn btn-sm btn-danger" onclick="deleteBooking(<?= $b['id'] ?>)">🗑</button>
    </td>
  </tr>
  <?php endforeach; ?>
<?php else: ?>
<tr><td colspan="5" class="text-center text-muted">No bookings found.</td></tr>
<?php endif; ?>
</tbody>
</table>
</div>

<script>
async function deleteBooking(id){
  if(!confirm("Delete this booking?")) return;
  const res = await fetch(`api.php?path=bookings/${id}`,{method:'DELETE'});
  const json = await res.json();
  alert(json.message);
  location.reload();
}
async function editBooking(id,seats){
  const newSeats = prompt("New number of seats:",seats);
  if(!newSeats) return;
  const res = await fetch(`api.php?path=bookings/${id}`,{
    method:'PUT',
    headers:{'Content-Type':'application/json'},
    body:JSON.stringify({seats:Number(newSeats)})
  });
  const json = await res.json();
  alert(json.message);
  location.reload();
}
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
